Scheler unterscheidet zehn idealtypische Fälle von Einsfühlung:

a) Identifizierungen des primitiven Denkens der Naturvölker unterster Stufe  ([[@scheler1973]], 30)

Lévy-Bruhl hat über solche Fälle berichtet und sie erklärt.

Beispiele:

- die Identifizierungen der Glieder eines Totems mit je einem Glieder der Totemtierart
- Identifikation des Menschen mit seinem Ahnen
	- Ahnenkult stellt bereits eine erste Befreiung von primitiver Einsfühlung von Enkel und Ahn dar und setzt das Bewusstsein von der individuellen Verschiedenheit von beiden Ichen voraus.
- Das Massenphänomen durch Selbstidentifizierung mit dem Führer (und durch ihn hindurch Einsfühlung der Massenteile miteinander)
- Reinkarnationslehre ist nur eine Rationalisierung der ursprünglichen Identifizierungen.

b) Echte Einsfühlung heteropathischer Art  ([[@scheler1973]], 31)

- Ekstatische Einsfühlung in den antiken Mysterien.
- In der Theater\- und Spielkunst wird die ekstatische *Eins*fühlung zu bloßer symbolischen *Ein*fühlung.

c)  ([[@scheler1973]], 31-34)

c.1) Hypnose

Besonders wenn das Verhältnis zwischen Hypnotiseur und Hypnotisiertem nicht nur ein vorübergehendes ist, sondern ein stabiles Dauerverhältnis solcher Art wird,

>„daß das Objekt der *Hypnose dauernd* in sämtliche individuelle Ichhaltungen des Hypnotiseurs ,hingerissen’ ist, es nur seine Gedanken denkt und seinen Willen will, seine Werte wertet, seine Liebe mitliebt, seinen Haß mithaßt – dabei aber überzeugt ist, daß dieses fremde Ich mit allen seinen Haltungen, Aktarten und -Formen das ,eigene’ sei.“  ([[@scheler1973]], 31).

Der Hypnotisierte identifiziert sich nicht mit dem Ich des Hypnotiseurs (wie bei den sogenannten „Identifizierungen“), sondern er übernimmt nur seine „*Soseins*identität bei Daseinsverschiedenheitsbewußtsein“  ([[@scheler1973]], 31).

c.2) Selbstunterwerfung

Zu dieser Art von Phänomenen der Einsfühlung gehört auch die Lust an der positiven *Selbstunterwerfung* des Schwachen gegenüber dem Starken.  ([[@scheler1973]], 32).

Ein Beweis hierfür ist der sog. Unterwerfungstrieb. Vgl. Schopenhauers Beispiel des weisen Eichhörnchen im indischen Urwald.  ([[@scheler1973]], 32-33).

c.3) Masochismus und Sadismus

Masochismus und Sadismus sind eine Ausgestaltung des erotischen Machtwillens.

>„Auch im Masochisten ist es nicht die pure Passivität als solche, sondern die einsfühlende Teilnahme an der Überaktivität des Partners, d.h. die *sympathetische Machtgewinnung*, die zum Gegenstand des Genusses wird.“  ([[@scheler1973]], 33)

Der Liebende identifiziert sich mit dem Geliebten und er nimmt die Erlebnisse des Anderen an sich, empfindet sie als eigene.

d) pathologische Einsfühlung

Freud bespricht diese Art von Einsfühlung in seiner Schrift *Massenpsychologie und Ichanalyse*. Er bietet dort jedoch eine nach Schelers Ansicht falsche Beschreibung des Ursprungs des Mitgefühls aus der Identifizierung (sprich Einsfühlung). Scheler macht hier nochmal deutlich, dass das Mitgefühl „die phänomenale Ichdistanz“ voraussetzt, die durch die Einsfühlung aufgehoben ist.

e) das kindliche Bewusstsein

Kinder neigen eher zur Einsfühlung (Identifizierung) als zur Einfühlung: „Was beim Erwachsenen Einfühlung ist, ist dort Einsfühlung“  ([[@scheler1973]], 35).

Scheler erwähnt als Beispiele das kindliche Spiel und die Reaktion von kleinen Kindern als Zuschauer im Theater oder vor dem Puppentheater.

Scheler erklärt, dass das kindliche Bewusstsein noch zu labil und inkohärent ist.

f) Bewusstseinsspaltungen

Z.B. Besessenheit.

Scheler erwähnt hier das Werk von Österreich, insbesondere *Phänomenologie des Ich* und *Die Besessenheit*.

Vgl. aber auch Stephens, G. Lynn, und George Graham. *When Self-Consciousness Breaks: Alien Voices and Inserted Thoughts*. Cambridge, Mass/London: MIT Press, 2003.

g) gegenseitige Verschmelzungsphänomen

Die elementarste Form dieser Einsfühlung stellt nach Scheler den liebeerfüllten Geschlechtsakt (im Gegenteil zum genießenden, gebrauchenden oder zweckhaften Akt), wobei

>„beide Teile unter rauschartiger Ausschaltung des geistigen Personseins […] in *einen* Lebensstrom, der keines der individuellen Iche mehr gesondert in sich enthält, der aber ebensowenig ein sich auf die beiderseitige Ichgegebenheit aufbauendes Wir-bewußtsein darstellt, zurückzutauchen meinen.“ ([[@scheler1973]], 36)

h) das Phänomen der unorganisierten Masse

Hier findet eine Einsfühlung aller Glieder einerseits mit dem Führer statt und eine dazutretende gegenseitige Verschmelzung der Glieder in *einem* Affekt\- und Triebstrom, der dann das Verhalten aller Teile von sich aus bedingt ([[@scheler1973]], 36).

i) Soseins-Einsfühlung

Die Theorie der Soseins-Einsfühlung stammt aus Eduard von Hartmann und Henri Bergson, die die sog. Identifikationstheorie der Liebe formuliert haben: Liebe bestehe in Aufnahme des Ich eines anderen ins eigene Ich durch Einsfühlung.

Beispiel hierfür ist der Konnex zwischen Mutter und Kind.

Nach Eduard von Hartmann ist Liebe nur Ausdehnung des Egoismus oder des Selbsterhaltungstriebs über das eigene Ich hinaus durch Aufnahme des fremden Ich in das eigene.

Scheler kritisiert von Hartmanns Theorie der Liebe. Die Mutter identifiziert sich mit dem Kind durch einen Akt der Einsfühlung. Im Gegensatz zum Mutterinstinkt erfasst erst die Mutterliebe das Kind als selbstständiges Wesen und nicht mehr als *terminus a quo*, sondern als *terminus ad quem*. ([[@scheler1973]], 38)

i) die Einsfühlung der Wespe in den Lebensprozess und Organismus der Raupe ([[@scheler1973]], 39-42)
