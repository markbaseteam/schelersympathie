source:: [[@scheler1973]], 29-48

[[@scheler1973]], 29:

- Einsfühlung ist ein Grenzfall der Ansteckung.
- Das fremde Ich wird mit dem eigenen Ich identifiziert.
- Lipps hat die ästhetische Einfühlung als Einsfühlung gedeutet, was nach Scheler (und Stein) falsch ist. Stein bringt dies klar auf den Punkt: der Zuschauer ist nicht eins mit dem Akrobaten, sondern nur be im.
- Einsfühlung kann eine momentane Ekstasis darstellen, oder aber sie kann für lange Zeit andauern, ja für ganze Lebensphasen habituell werden.
- Es gibt zwei fundamentale Typen von Einsfühlung:
	1. idiopathische Einsfühlung: das fremde Ich wird durch das eigene Ich aufgesogen, in es hereingenommen;
	2. heteropathische Einsfühlung: das eigene Ich wird von dem anderen Ich absorbiert, sodass „an meine formale Ich-Stelle ganz das fremde individuelle Ich tritt mit allen *ihm* wesentlichen Grundhaltungen“ ([[@scheler1973]], 30).

##### Idealtypische Fälle der Einsfühlung

![[Idealtypische Fälle der Einsfühlung]]

##### Ort der Einsfühlung

Ort der Einsfühlung ist das Vitalbewusstsein.

##### Bedingungen des Zustandekommens der Einsfühlung

1. Automatismus
2. Heroismus und Verdummung
