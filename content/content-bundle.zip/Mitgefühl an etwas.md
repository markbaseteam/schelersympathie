Mitgefühl an etwas

- Das ist nach Scheler das Mitgefühl im eigentlichen Sinne.
