- Scheler unterscheidet vier Arten des Mitgefühls ([[@scheler1973]], 23)
	1. Miteinanderfühlen
	2. Mitgefühl an etwas
	3. Gefühlsansteckung
	4. Einsfühlung