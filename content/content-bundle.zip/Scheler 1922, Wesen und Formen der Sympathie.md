---
alias: [Wesen und Formen der Sympathie]
---

# Scheler 1913, Wesen und Formen der Sympathie

- Author:: [[Scheler|Max Scheler]]
- Year:: 1913/1922
- Title:: Wesen und Formen der Sympathie
- source:: [[@scheler1973]]
- [[@scheler1973]] = Scheler, Max. *Wesen und Formen der Sympathie – Die deutsche Philosophie der Gegenwart*. Herausgegeben von Manfred S. Frings. 6., Durchges. Aufl. Gesammelte Werke 7. Bern, München: Francke, 1973.

# Vorwort zur ersten Auflage

# Vorwort zur zweiten Auflage

# Vorwort zur dritten Auflage

# A. Das Mitgefühl

## I. Die sogenannte Sympathieethik

Scheler nennt zwei Gründe, warum eine Ethik, die in dem Mitgefühl den höchsten sittlichen Wert sieht, niemals den Tatsachen des sittlichen Lebens gerecht werden kann.

### 1. Erster Grund

Mitgefühl ist „als solches ganz bilind für den Wert seines Erlebens“ ( [[@scheler1973]], 17), „ist in jeder seiner möglichen Formen prinzipiell *wertblind*“ ( [[@scheler1973]], 18).

### 2. Zweiter Grund

## II. Scheidungen in den Phänomenen des „Mitgefühls“

### Nachgefühl vs. Mitgefühl

#### Differenzierung zwischen Mitgefühl und Nachgefühl

![[Unterschied zwischen Mitgefühl und Nachgefühl]]

#### Ausdrucksphänomen nach Scheler

![[Ausdrucksphänomen nach Scheler]]

#### Schelers Kritik der Nachahmungstheorie der Einfühlung

![[Schelers Kritik der Nachahmungstheorie der Einfühlung]]

#### Schelers Kritik der Theorie des Analogieschlusses

![[Schelers Kritik der Theorie des Analogieschlusses]]

### Typen von Mitgefühl

#### Differenzierungen des Mitgefühls

![[Differenzierungen des Mitgefühls]]

#### Miteinander-Fühlen![[Miteinander-fühlen]]

#### Mitgefühl an etwas![[Mitgefühl an etwas]]

#### Gefühlsansteckung

#### Einsfühlung

![[Einsfühlung]]

#### Entwicklung ist nie bloß Fortschritt, sondern auch gleichzeitig Dekadenz

Leben und Menschen haben in ihrer Entwicklung nicht nur wesentlich neue Fähigkeiten gewonnen, sondern auch welche verloren.

Synthese von Fortschritt und Bewahrung ist das Ideal, das gelten muss. [[@scheler1973]], 43

## III. Genetische Theorien des Mitgefühls

