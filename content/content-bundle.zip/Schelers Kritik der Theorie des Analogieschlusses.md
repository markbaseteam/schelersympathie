1. Was ist die Theorie des Analogieschlusses
2. Schelers Argumente gegen die Theorie des Analogieschlusses

Was ist die Theorie des Analogieschlusses

 Schelers Argumente gegen die Theorie des Analogieschlusses
 
1. Die Annahme, dass es zuerst nur einen Körper gegeben ist, ist „völlig irrig.“ ([[@scheler1973]], 21)
