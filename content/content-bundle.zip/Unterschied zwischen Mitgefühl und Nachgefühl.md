[[@scheler1973]], 19

- Mitgefühl setzt „eine Form des Wissens um die Tatsache fremder Erlebnisse, ihre Natur und Qualitäten“ voraus.
- Die Gegebenheit fremder Erlebnisse konstituiert sich nicht in Mitgefühl.

[[@scheler1973]], 20

- „Das ,Nachfühlen‘ bleibt noch in der Sphäre des *erkennenden* Verhaltens und ist kein sittlich relevanter Akt.“
- Nachgefühl bleibt nichtsdestotrotz „ein Fühlen des fremden Gefühls, kein bloßes Wissen um es oder nur ein Urteil, der andere habe das Gefühl“.
- Nachgefühl ist „kein Erleben des wirklichen Gefühles als eines Zustandes. Wir erfassen im Nachfühlen fühlend noch die *Qualität* des fremden Gefühls – *ohne* daß es in uns herüberwandert oder ein gleiches reales Gefühl in uns erzeugt wird.“
- Analogie mit dem Erinnerungsbewusstsein.

[[@scheler1973]], 22

- Ich brauche nicht in mir die Todesangst eines Ertrinkenden zu erleben, um seine Angst zu verstehen (d.i. nachzufühlen).S

[[@scheler1973]], 23

- Dann würde man Nachfühlen mit „*Ansteckung* durch fremde Affekte“ identifizieren. Aber Nachgefühl und Gefühlsansteckung sind verschiedene Phänomene.

[[@scheler1973]], 20-21

- Nachfühlen lässt sich weder durch die Theorie des Analogieschlusses noch durch die Nachahmungstheorie erklären.
- Siehe [[Schelers Kritik der Nachahmungstheorie der Einfühlung]]
- Siehe [[Schelers Kritik der Theorie des Analogieschlusses]]
- Siehe [[Ausdrucksphänomen nach Scheler]]
