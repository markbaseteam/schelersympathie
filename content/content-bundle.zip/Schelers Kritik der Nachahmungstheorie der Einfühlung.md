1. Was sagt die Nachahmungstheorie?
2. Wie kritisiert Scheler die Nachahmuntstheorie?

- Scheler nennt Lipps Theorie auch „projektive Einfühlungstheorie“ ([[@scheler1973]], 25 Anm. 1).0

- „Gegen die Nachahmungstheorie von Lipps spricht ferner, daß wir die Erlebnisse z.B. an Tieren verstehen können, deren Ausdrucksbewegungen wir auch der bloßen ,Tendenz‘ nach nicht nachzuahmen vermögen, z.B. wenn ein Hund durch Bellen und Mit-dem-Schweife-wedeln oder ein Vogel durch Zwitschern seine Freude ausdrückt.“ ([[@scheler1973]], 22)
