[[@scheler1973]], 21

- Die Erlebnisse des Anderen sind uns in den „Ausdrucksphänomenen“ gegeben „im Sinne originären ,Wahrnehmens‘: wir nehmen die Scham *im* Erröten wahr, *im* Lachen die Freude.“
- „Denn eine „*Symbolbeziehung*, keine Kausalbeziehung liegt hier vor.“

[[@scheler1973]], 21 Anm. 1

- Hier liegt keine Beziehung des „Anzeichens“ für das Vorhandensein „von etwas“, das sich erst in einem logischen Schluss realisiert, vor.
- Es handelt sich um eine Beziehung eines echten ursprünglichen „Zeichenseins“.

Edmund Husserls *Erste Logische Untersuchung: Ausdruck und Bedeutung* (1901), Erstes Kapitel: „Die wesentlichen Unterscheidungen“

[[@scheler1973]], 22

- „*universale Grammatik*, die für alle Sprachen des Ausdrucks gilt und oberste Verständnisgrundlage für alle Arten von Mimik und Pantomimik des Lebendigen ist“.
- Die Annahme der Existenz einer solchen Grammatik des Ausdrucks erklärt, inwiefern man die „*Inadäquatheit*“ eines Ausdrucks mit dem Erlebnis wahrnehmen kann: d.h. der „Widerstreit“ zwischen Ausdrucksbewegung und ausgedrücktem Gefühl.
